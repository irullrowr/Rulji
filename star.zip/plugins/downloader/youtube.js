const fetch = require('node-fetch');

const types = [ 'video', 'audio' ];
const qualityVideo = [ '144', '240', '360', '480', '720' ];
const qualityAudio = [ '32', '64', '128', '192' ];

const youtubeDownloader = {
detail: async (url) => {
try {
const response = await (await fetch(`https://cdn59.savetube.su/info?url=${url}`)).json();
const data = response.data;
const result = {
status: true,
title: data.title,
url: data.url,
duration: data.durationLabel,
thumbnail: data.thumbnail_formats[0].url,
id: data.id,
access: data.key
}
return result;
} catch (error) {
return {
status: false,
message: error.message
}
console.log('Error:' + error);
}
},
media: async (type, quality, key) => {
try {
const response = await (await fetch(`https://cdn51.savetube.su/download/${type}/${quality}/${key}`)).json();
const data = response.data;
if (data && data.downloadUrl) {
return {
status: true,
url: data.downloadUrl
};
} else {
return {
status: false,
message: "Download URL tidak ditemukan."
};
}
} catch (error) {
return {
status: false,
message: error.message
}
console.log('Error:' + error);
}
},
download: async (url, type, quality) => {
try {
const data = await youtubeDownloader.detail(url);
const { access } = data;
const mediaResult = await youtubeDownloader.media(type, quality, access);

return {
status: true,
data,
media: mediaResult
};
} catch (error) {
return {
status: false,
message: error.message
}
console.log('Error:' + error);
}
}
}

exports.run = {
usage: ['ytmp3', 'ytmp4'],
hidden: ['yta', 'ytv'],
use: 'link',
category: 'downloader',
async: async (m, { func, mecha, users, setting, YT }) => {
try {
if (/yt?(a|mp3)/i.test(m.command)) {
if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
const result = await youtubeDownloader.detail(m.args[0])
if (!result.status) return m.reply(result.message)
let txt = `乂  *YOUTUBE DOWNLOADER MP3*\n`
txt += `\n◦ VideoId : ${result.id}`
txt += `\n◦ Title : ${result.title}`
txt += `\n◦ Duration : ${result.duration}`
txt += `\n◦ URL Video : ${result.url}`
txt += `\n◦ Key : ${result.access}`
txt += `\n\nPlease wait, the audio file is being sent...`
mecha.sendMessageModify(m.chat, txt, m, {
largeThumb: true,
thumbnail: await func.fetchBuffer(result.thumbnail)
}).then(async () => {
let audio = await youtubeDownloader.media('audio', '128', result.access);
if (!audio.status) return m.reply(audio.message);
mecha.sendMessage(m.chat, {
audio: {
url: audio.url
},
mimetype: 'audio/mpeg', 
}, {quoted: m, ephemeralExpiration: m.expiration})
})
} else if (/yt?(v|mp4)/i.test(m.command)) {
if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
const result = await youtubeDownloader.detail(m.args[0])
if (!result.status) return m.reply(result.message)
let txt = `乂  *YOUTUBE DOWNLOADER MP4*\n`
txt += `\n◦ VideoId : ${result.id}`
txt += `\n◦ Title : ${result.title}`
txt += `\n◦ Duration : ${result.duration}`
txt += `\n◦ URL Video : ${result.url}`
txt += `\n◦ Key : ${result.access}`
txt += `\n\nPlease wait, the video file is being sent...`
mecha.sendMessageModify(m.chat, txt, m, {
largeThumb: true,
thumbnail: await func.fetchBuffer(result.thumbnail)
}).then(async () => {
let video = await youtubeDownloader.media('video', '720', result.access);
if (!video.status) return m.reply(video.message);
mecha.sendMessage(m.chat, {
video: {
url: video.url
},
mimetype: 'video/mp4',
}, {quoted: m, ephemeralExpiration: m.expiration})
})
}
} catch (e) {
return mecha.reply(m.chat, func.jsonFormat(e), m)
}
},
limit: 3
}