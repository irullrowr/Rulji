const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');
const fs = require('fs');

const svweb = async (link, responseType = 1, convertOption = '--convert') => {
try {
const { data } = await axios.post('https://tella.mockso-cloud.com/screenshot/video', {
url: link
}, {
headers: {
'Content-Type': 'application/json',
'User-Agent': 'Postify/1.0.0'
},
responseType: 'arraybuffer'
});

const result = responseType === 1 ? Buffer.from(data) : Buffer.from(data).toString('base64');
const domainName = new URL(link).hostname.replace('www.', '').split('.')[0];

if (result.length < 1024) {
throw new Error('Website tersebut tidak dapat terhubung..');
}

if (convertOption === '--convert') {
const fileName = `${domainName}_video.mp4`;
const filePath = path.join(process.cwd(), 'downloads', fileName);
await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
await fs.promises.writeFile(filePath, result, responseType === 1 ? null : 'base64');
console.log(`Video telah disimpan ke ${filePath}`);
return { filePath, data: result };
} 

if (convertOption === '--unconvert') {
return { type: responseType === 1 ? 'buffer' : 'base64', data: result };
}

throw new Error('❌ Opsi konversinya kagak valid. pake --convert atau --unconvert yakk...');
} catch (error) {
console.error(error.message);
throw error;
}
};

exports.run = {
usage: ['svweb', 'ssweb'],
use: 'url',
category: 'tools',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply('Masukkan URL nya.')
if (!func.isUrl(m.args[0])) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
try {
let result = await svweb(m.text, 1, '--unconvert');
mecha.sendMedia(m.chat, result.data, m, {
expiration: m.expiration,
caption: global.mess.ok
});
} catch (error) {
return m.reply(error.toString())
}
},
limit: 3
}