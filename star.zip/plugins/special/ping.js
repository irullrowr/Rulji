const { performance } = require('perf_hooks');
const os = require('os');

exports.run = {
usage: ['ping'],
category: 'special',
async: async (m, { func, mecha }) => {
const start = performance.now();

const [totalMemGB, freeMemGB, uptime, cpuInfo] = await Promise.all([
(os.totalmem() / 1024 ** 3).toFixed(2) + " GB",
(os.freemem() / 1024 ** 3).toFixed(2) + " GB",
os.uptime(),
os.cpus()[0]?.model ?? 'Tidak diketahui'
]);

const days = Math.floor(uptime / 86400);
const hours = Math.floor((uptime % 86400) / 3600);
const minutes = Math.floor((uptime % 3600) / 60);
const seconds = Math.floor(uptime % 60);

const speed = (performance.now() - start).toFixed(5) + " ms";

const serverInfo = `Server Information

- ${os.cpus().length} CPU: ${cpuInfo}
- Uptime: ${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik
- RAM: ${freeMemGB}/${totalMemGB}
- Speed: ${speed}`;

await mecha.reply(m.chat, func.texted('monospace', serverInfo), m, {
expiration: m.expiration
});
}
};