// === Owner & Developer Settings ===
global.owner = '13433420389@s.whatsapp.net';       // Owner Number
global.ownerName = 'Irx';                           // Owner Name
global.developer = [                                  // Developers with Special Access
  '13433420389',
  '6285702691440',
  '6285646584823'
].map(num => num.replace(/[^0-9]/g, '') + '@s.whatsapp.net');

// === Bot Identity ===
global.botName = 'BiteID';                        // Bot Name
global.fake = 'BiteID';                               // Fake Info in Some Features
global.header = `BiteID v${require('./package.json').version}`;  // Header Info
global.footer = 'BiteID';                             // Footer Info

// === Bot Functional Settings ===
global.cooldown = 1;                                  // Anti-Spam Delay (Seconds)
global.max_ram = 3;                                   // Max RAM for Auto Restart (GB)
global.blocks = ['91', '92', '212'];                  // Blacklisted Country Codes
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i;  // Command Prefix Options

// === Channel & QRIS URLs ===
global.newsletter = '120963218115693753@newsletter';  // Newsletter Channel ID
global.qrisUrl = 'https://telegra.ph/file/f8a4db79114df3cabe364.jpg'; // QRIS for Payments
global.audioUrl = 'https://files.catbox.moe/c8llw1.mp3';              // Audio URL for Menu

// === Pairing Settings ===
global.pairing = {
  status: true,                                       // Set to false to use QR
  number: '33221851628'                              // Bot Number
};

// === APIs & Databases ===
global.quoteApi = 'https://bot.lyo.su/quote/generate'; // Quick Chat API
global.mongoUrl = '';                                  // MongoDB URL (register at https://www.mongodb.com/)

// === Bot Messages ===
global.mess = {
  wait: 'Prosses . . .',
  ok: '',
  limit: 'Anda telah mencapai limit dan akan disetel ulang pada pukul 00.00\n\n> untuk mendapatkan limit tak terbatas, tingkatkan ke paket premium.',
  premium: 'This feature only for premium user.',
  jadibot: 'This feature only for jadibot user.',
  owner: 'This feature is only for owners.',
  devs: 'This feature is only for developers.',
  group: 'This feature will only work in groups.',
  private: 'Use this feature in private chat.',
  admin: 'This feature only for group admin.',
  botAdmin: 'This feature will work when I become an admin',
  gconly: 'Bot hanya dapat digunakan di dalam grup.',
  bot: 'This feature can only be accessed by bots',
  wrong: 'Wrong format!',
  error: {
    url: 'URL is Invalid!',
    api: 'Sorry an error occurred!'
  },
  block: {
    owner: 'This feature is being blocked by owner!',
    system: 'This feature is being blocked by system because an error occurred!'
  },
  query: 'Enter search text',
  search: 'Searching . . .',
  scrap: 'Scrapping . . .',
  wrongFormat: 'Incorrect format, please look at the menu again',
  game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan.'
};

// === Clear Cache After Update ===
require('./system/functions.js').reloadFile(__filename);
